//main system
import "./system/CommandHandler.js"