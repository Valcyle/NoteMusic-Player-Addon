import { song1 } from "./Song1";
import { song2 } from "./Song2";

export const musics = {
    1:{
        title: "song1",
        length: 10,
        file: "Song1",
        note: song1
    },
    2:{
        title: "song2",
        length: 15,
        file: "Song2",
        note: song2
    },
}