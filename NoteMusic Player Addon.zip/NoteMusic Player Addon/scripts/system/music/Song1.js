export const song1 = [
    [
        {type: "harp", pitch: "G2"},
        {type: "harp", pitch: "G"}
    ],
    [
        {type: "harp", pitch: "F"}
    ],
    [
        {type: "harp", pitch: "E"}
    ],
    [
        {type: "harp", pitch: "D"}
    ],
    [
        {type: "harp", pitch: "C"},
        {type: "harp", pitch: "C2"}
    ]
]