export const song2 = [
    [
        {type: "harp", pitch: "C"}
    ],
    [
        {type: "harp", pitch: "D"}
    ],
    [
        {type: "harp", pitch: "E"}
    ],
    [
        {type: "harp", pitch: "F"}
    ],
    [
        {type: "harp", pitch: "G2"}
    ]
]